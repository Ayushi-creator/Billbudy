package com.ansari.split_with_room_mates;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SplitWithRoomMatesApplicationTests {

	@Test
	void contextLoads() {
	}

}
