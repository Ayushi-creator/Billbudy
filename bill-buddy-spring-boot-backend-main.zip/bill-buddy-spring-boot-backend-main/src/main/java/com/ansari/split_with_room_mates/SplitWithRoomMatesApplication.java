package com.ansari.split_with_room_mates;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SplitWithRoomMatesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SplitWithRoomMatesApplication.class, args);
	}

}
